class cuadrado:
  def __init__(self,lado1,lado2):
    self.lado1 = lado1
    self.lado2 = lado2
  def area(self):
    result = self.lado1*self.lado2
    return result

c=cuadrado( 5 , 5)
print( c.area())