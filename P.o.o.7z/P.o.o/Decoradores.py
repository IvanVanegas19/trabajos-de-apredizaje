class Aprendiz:
  def __init__(self,name,surname,old,movil):
    self.name=name
    self.surname=surname
    self.old=old
    self.movil=movil
    
    @property
    def name(self):
      return self.name
    
    @name.setter
    def name(self,name):
      self.name = name
    
    @property
    def surname(self):
      return self.surname
    
    @name.setter
    def surname(self,surname):
      self.surname = surname
    
    @property
    def old(self):
      return self.old
    
    @name.setter
    def old(self,old):
      self.old = old
    
    @property
    def movil(self):
      return self.movil
    
    @name.setter
    def movil(self,movil):
      self.movil = movil
  
  def impri(self):
    print(f"{self.name},{self.surname},{self.old},{self.movil}")
      
apre=Aprendiz(input("escriba su nombre"),input("escriba su apellido"),int(input("escriba su edad")),int(input("escriba su numero de telefono")))
apre.name="Kayn"
apre.surname="Sheida"
apre.impri()