class Aprendiz:
	def __init__(self,nombre,apellido,id,movil,edad):
		self.nombre = nombre
		self.apellido =apellido
		self.id = id
		self.movil = movil
		self.edad = edad
	def impri(self):
		print(f'persona:{self.nombre} {self.apellido} {self.id} {self.movil}')
ma=Aprendiz("ivan","vaneags","1027522344","3102748633","18")
print(ma.nombre)