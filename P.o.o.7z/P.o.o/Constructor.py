""" Primer Ejercicios"""
"""class Usario:
  def __init__(self,name,old,Cc):
    self.name=name
    self.old=old
    self.Cc=Cc
    
    @property
    def name(self):
      return self.name
    
    @name.setter
    def name(self,name):
      self.name = name
    
    @property
    def old(self):
      return self.old
    
    @name.setter
    def old(self,old):
      self.old = old
    
    @property
    def Cc(self):
      return self.Cc
    
    @name.setter
    def Cc(self,Cc):
      self.Cc = Cc
    
  def mostar(self):
    if self.old >= 18:
      print(f"{self.name} Es mayor de edad")
    else:
      print(f"{self.name} Es menor de edad")      
usu=Usario(input("escriba su nombre"),int(input("escriba su edad")),int(input("escriba su numero de Cc")))
usu.mostar()"""

"""Segundo Ejercicios"""
class cuenta:
  def __init__(self,titular,cantidad):
    self.titular = titular
    self.cantidad = cantidad
    
    @property
    def titular(self):
      return self.titular
    
    @titular.setter
    def titular(self,titular):
      self.titular = titular
    
    @property
    def cantidad(self):
      return self.cantidad
    
    @cantidad.setter
    def cantidad(self,cantidad):
      self.cantidad = cantidad
  def retirar(self):
      reti=float
  def mostar(self):
    print(f"El propetario de la cuenta es{self.titular}")
    
ti=cuenta(input("escriba su nombre titular"),int(input("Escriba la cantidad o valor de su cuenta")))